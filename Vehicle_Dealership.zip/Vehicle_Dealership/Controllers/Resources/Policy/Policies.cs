namespace SaleIt.Controllers.Resources.Policy
{
    public static class Policies
    {
        public const string RequriedAdminRole = "RequriedAdminRole";

        public const string RequriedModeratorRole = "RequriedModeratorRole";
    }
}