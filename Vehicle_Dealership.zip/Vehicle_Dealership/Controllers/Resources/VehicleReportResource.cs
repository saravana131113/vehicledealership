namespace SaleIt.Controllers.Resources
{
    public class VehicleReportResource
    {
        public string MakeName { get; set; }
        public int TotalVehicles { get; set; }
    }
}