namespace SaleIt.Core.Models
{
    public class VehicleReport
    {
        public string MakeName { get; set; }
        public int TotalVehicles { get; set; }
    }
}